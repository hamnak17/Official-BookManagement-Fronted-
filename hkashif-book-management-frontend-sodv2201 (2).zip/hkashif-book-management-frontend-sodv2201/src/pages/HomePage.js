import React, { useState } from 'react';
import BookList from '../components/BookList';
import { useNavigate } from 'react-router-dom'; // For navigation
import './HomePage.css'; // Importing the CSS file for HomePage styles

const HomePage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  const handleLogin = () => {
    navigate('/login'); // Navigate to login page
  };

  return (
    <div className="home-page-container">
      <h1 className="home-page-heading">Welcome to the Book Management App</h1> {/* Updated to h1 with a class */}

      {/* Search bar and login section */}
      <div className="search-login-container">
                {/* Search bar */}
        <div className="search-container">
          <input
            type="text"
            className="search-input"
            placeholder="Search by title or author"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)} // Update searchTerm as user types
          />
          {/* Profile image */}
        <div className="profile-container">
          <img
            src="https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_1280.png"
            alt="Profile"
            className="profile-image"
          />
        </div>
          {/* Login button */}
          <button className="login-btn" onClick={handleLogin}>Login</button>
        </div>
      </div>

      {/* Pass searchTerm to BookList */}
      <BookList searchTerm={searchTerm} />
    </div>
  );
};

export default HomePage;
