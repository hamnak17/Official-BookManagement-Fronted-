import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import AdminDashboard from './components/AdminDashboard';
import AddBook from './components/AddBook';
import EditBook from './components/EditBook';
import BookDetails from './components/BookDetail'; // Import your BookDetails component
import HomePage from './pages/HomePage';
import Login from './components/Login';
import ProtectedRoute from './components/ProtectedRoute';

const App = () => {
  const [isAuthenticated, setIsAuthenticated] = React.useState(
    !!localStorage.getItem('authToken')
  );

  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/login" element={<Login setIsAuthenticated={setIsAuthenticated} />} />
      <Route
        path="/admin-dashboard"
        element={
          <ProtectedRoute isAuthenticated={isAuthenticated}>
            <AdminDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/add-book"
        element={
          <ProtectedRoute isAuthenticated={isAuthenticated}>
            <AddBook />
          </ProtectedRoute>
        }
      />
      <Route
        path="/edit-book/:id"
        element={
          <ProtectedRoute isAuthenticated={isAuthenticated}>
            <EditBook />
          </ProtectedRoute>
        }
      />
      <Route
        path="/books/:id"
        element={
          <ProtectedRoute isAuthenticated={isAuthenticated}>
            <BookDetails />
          </ProtectedRoute>
        }
      />
    </Routes>
  );
};

export default App;
