import axios from 'axios';

const API = axios.create({
  baseURL: 'http://localhost:7000',
});

// Login function
export const login = async ({ username, password }) => {
  try {
    const response = await API.post('/login', { username, password });
    return response.data; // Return the token or any other response data
  } catch (err) {
    throw new Error('Login failed'); // Handle errors appropriately
  }
};

export default API;
