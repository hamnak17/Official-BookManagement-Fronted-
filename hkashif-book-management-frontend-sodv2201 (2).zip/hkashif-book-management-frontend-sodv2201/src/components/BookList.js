import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './BookList.css';
import './AdminDashboard.css';

const BookList = ({ searchTerm, isAdmin }) => {
  const [books, setBooks] = useState([]);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  // Fetch books data from the API
  useEffect(() => {
    const fetchBooks = async () => {
      try {
        const response = await axios.get('http://localhost:7000/books'); // API URL
        setBooks(response.data);
        setError(null); // Clear error if the request is successful
      } catch (err) {
        // Set a custom error message based on the error response
        if (err.response && err.response.status === 404) {
          setError('No books found. Please try again.');
        } else {
          setError('Could not fetch books. Please try again later.');
        }
      }
    };
    fetchBooks();
  }, []);

  // Filter books based on the search term, including publication date
  const filteredBooks = books.filter((book) =>
    book.title.toLowerCase().includes(searchTerm?.toLowerCase() || '') ||
    book.author.toLowerCase().includes(searchTerm?.toLowerCase() || '') ||
    (book.publicationDate && book.publicationDate.includes(searchTerm?.toLowerCase() || ''))
  );

  return (
    <div className={isAdmin ? 'admin-dashboard' : 'book-list-container'}>
      {isAdmin && <h2>Admin Dashboard</h2>}
      {error && <p style={{ color: 'red' }}>{error}</p>} {/* Error message display */}
      <div className={isAdmin ? 'admin-book-list' : 'book-list'}>
        {filteredBooks.length > 0 ? (
          filteredBooks.map((book) => (
            <div key={book.id} className="book-card">
              {book.coverImage && (
                <img src={book.coverImage} alt={book.title} className="book-image" />
              )}
              <h3>{book.title}</h3>
              <p>{book.author}</p>
              <p><strong>Published:</strong> {book.publicationDate || 'N/A'}</p> {/* Display publication date */}
              {isAdmin ? (
                <div className="button-container">
                  <button onClick={() => console.log(`Edit ${book.id}`)}>Edit</button>
                  <button onClick={() => console.log(`Delete ${book.id}`)}>Delete</button>
                </div>
              ) : (
                <button onClick={() => navigate(`/books/${book.id}`)}>View Details</button>
              )}
            </div>
          ))
        ) : (
          !error && <p>No books found</p> // Prevent duplicate error message
        )}
      </div>
    </div>
  );
};

export default BookList;
