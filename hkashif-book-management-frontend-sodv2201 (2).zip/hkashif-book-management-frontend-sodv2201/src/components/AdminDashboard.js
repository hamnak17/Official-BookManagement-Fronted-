import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './AdminDashboard.css';
import DeleteConfirmationModal from './modals/DeleteConfirmationModal';

const axiosInstance = axios.create({
  baseURL: 'http://localhost:7000',
});

const AdminDashboard = () => {
  const [books, setBooks] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [bookToDelete, setBookToDelete] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('authToken');
    if (token) {
      axiosInstance.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    } else {
      navigate('/login');
    }
  }, [navigate]);

  useEffect(() => {
    const fetchBooks = async () => {
      try {
        const response = await axiosInstance.get('/books');
        setBooks(response.data);
      } catch (err) {
        console.error('Error fetching books:', err);
        setErrorMessage('Failed to load books. Please try again later.');
        if (err.response && err.response.status === 401) {
          localStorage.removeItem('authToken');
          navigate('/login');
        }
      }
    };

    fetchBooks();
  }, [navigate]);

  const handleDelete = async () => {
    try {
      await axiosInstance.delete(`/books/${bookToDelete.id}`);
      setBooks(books.filter((book) => book.id !== bookToDelete.id));
      setShowModal(false);
      setSuccessMessage('Book deleted successfully!');
      setTimeout(() => {
        setSuccessMessage('');
        navigate('/'); // Redirect to homepage
      }, 2000);
    } catch (err) {
      console.error('Error deleting book:', err);
      setErrorMessage('Failed to delete the book. Please try again later.');
      setTimeout(() => setErrorMessage(''), 3000);
    }
  };

  const handleEdit = (id) => {
    navigate(`/edit-book/${id}`);
  };

  const handleAddBook = () => {
    navigate('/add-book');
  };

  const handleDeleteClick = (book) => {
    setBookToDelete(book);
    setShowModal(true);
  };

  return (
    <div className="admin-dashboard">
      <h2>Admin Dashboard</h2>
      <button className="add-book-button" onClick={handleAddBook}>
        Add New Book
      </button>

      {errorMessage && <p className="error-message">{errorMessage}</p>}

      <div className="book-list">
        {books.map((book) => (
          <div key={book.id} className="book-card">
            <img src={book.coverImage} alt={book.title} className="book-image" />
            <h3>{book.title}</h3>
            <p>{book.author}</p>
            <div className="button-container">
              <button onClick={() => handleEdit(book.id)} className="edit-btn">Edit</button>
              <button onClick={() => handleDeleteClick(book)} className="delete-btn">Delete</button>
            </div>
          </div>
        ))}
      </div>

      {successMessage && <p className="success-message">{successMessage}</p>}

      {showModal && (
        <DeleteConfirmationModal
          showModal={showModal}
          onDelete={handleDelete}
          onCancel={() => setShowModal(false)}
        />
      )}
    </div>
  );
};

export default AdminDashboard;
