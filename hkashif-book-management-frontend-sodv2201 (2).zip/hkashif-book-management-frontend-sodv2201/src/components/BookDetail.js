import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './BookDetail.css'; // Import the CSS file for styling

const BookDetail = () => {
  const { id } = useParams(); // Get the book id from the URL
  const [book, setBook] = useState(null); // State to store book data
  const [error, setError] = useState(''); // State to store error messages
  const navigate = useNavigate(); // For navigation

  useEffect(() => {
    const fetchBook = async () => {
      try {
        const token = localStorage.getItem('authToken'); // Retrieve token from localStorage
        if (!token) {
          navigate('/login'); // Redirect to login if no token
          return;
        }

        const response = await axios.get(`http://localhost:7000/books/${id}`, {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in headers
          },
        });

        setBook(response.data); // Set the fetched book data
      } catch (error) {
        console.error('Error fetching book details:', error);
        setError('Failed to load book details. Please try again.');
      }
    };

    fetchBook();
  }, [id, navigate]);

  if (error) {
    return <div className="error-message">{error}</div>; // Show error message if any
  }

  if (!book) return <div>Loading...</div>; // Show loading spinner or message

  return (
    <div className="book-detail">
      {/* Display book cover image or placeholder */}
      <img
        src={book.coverImage || 'https://via.placeholder.com/150'}
        alt={book.title || 'No Title Available'}
        className="book-detail-image"
      />

      {/* Display book details */}
      <h1>{book.title || 'No Title Available'}</h1>
      <h2>{book.author || 'No Author Available'}</h2>
      <p>{book.description || 'No Description Available'}</p>

      {/* Back to Home Page Button */}
      <button className="back-to-list-btn" onClick={() => navigate('/')}>
        Back to Home Page
      </button>
    </div>
  );
};

export default BookDetail;
