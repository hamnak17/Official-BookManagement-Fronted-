import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './AddBook.css';

const AddBook = () => {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [description, setDescription] = useState('');
  const [coverImage, setCoverImage] = useState('');
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const navigate = useNavigate();

  // Handle form submission for adding a new book
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title || !author || !description || !coverImage) {
      setError('All fields are required.');
      return;
    }
    try {
      const token = localStorage.getItem('authToken'); // Get token from localStorage
      if (!token) {
        setError('Authentication required. Please log in.');
        navigate('/login'); // Redirect to login if no token
        return;
      }

      await axios.post(
        'http://localhost:7000/books',
        { title, author, description, coverImage },
        {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in headers
          },
        }
      );

      setSuccessMessage('Book added successfully!');
      setTimeout(() => {
        navigate('/'); // Redirect to the homepage after adding a book
      }, 2000);
    } catch (err) {
      setError(
        err.response?.status === 401
          ? 'Unauthorized. Please log in again.'
          : 'Error adding book. Please try again.'
      );
      console.error('Error adding book:', err);
      if (err.response && err.response.status === 401) {
        localStorage.removeItem('authToken'); // Clear invalid token
        navigate('/login'); // Redirect to login
      }
    }
  };

  return (
    <div className="add-new-book">
      <h1>Add New Book</h1>
      {error && <p style={{ color: 'red' }}>{error}</p>} {/* Display error messages */}
      {successMessage && <p style={{ color: 'green' }}>{successMessage}</p>} {/* Display success messages */}
      <form onSubmit={handleSubmit}>
        <div>
          <label>Title:</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Author:</label>
          <input
            type="text"
            value={author}
            onChange={(e) => setAuthor(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Description:</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Cover Image URL:</label>
          <input
            type="url"
            value={coverImage}
            onChange={(e) => setCoverImage(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="add-book-button">
          Add Book
        </button>
      </form>
    </div>
  );
};

export default AddBook;
