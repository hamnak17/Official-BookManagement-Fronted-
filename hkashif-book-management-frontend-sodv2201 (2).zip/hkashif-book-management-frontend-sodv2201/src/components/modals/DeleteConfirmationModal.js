import React from 'react';
import '../../components/Modal.css'

const DeleteConfirmationModal = ({ showModal, onDelete, onCancel }) => {
  if (!showModal) return null; // Don't render anything if the modal isn't visible

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <h2>Are you sure you want to delete this book?</h2>
        <div className="modal-buttons">
          <button className="confirm-button" onClick={onDelete}>
            Confirm
          </button>
          <button className="cancel-button" onClick={onCancel}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default DeleteConfirmationModal;
