import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './EditBook.css';

const EditBook = () => {
  const { id } = useParams(); // Extract the book ID from the route
  const navigate = useNavigate(); // Navigation hook
  const [bookData, setBookData] = useState({
    title: '',
    author: '',
    description: '',
    coverImage: '',
  }); // State for book data
  const [error, setError] = useState(''); // State for error messages
  const [successMessage, setSuccessMessage] = useState(''); // State for success messages

  // Fetch book details when the component mounts
  useEffect(() => {
    const fetchBookDetails = async () => {
      try {
        const token = localStorage.getItem('authToken'); // Get token from localStorage
        if (!token) {
          navigate('/login'); // Redirect if no token
          return;
        }

        const response = await axios.get(`http://localhost:7000/books/${id}`, {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in headers
          },
        });
        setBookData(response.data); // Update book data
      } catch (err) {
        console.error('Error fetching book details:', err);
        setError('Error fetching book details. Please try again.');
        if (err.response && err.response.status === 401) {
          localStorage.removeItem('authToken'); // Clear invalid token
          navigate('/login'); // Redirect to login if unauthorized
        }
      }
    };

    fetchBookDetails();
  }, [id, navigate]);

  // Handle form input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setBookData({ ...bookData, [name]: value });
  };

  // Handle form submission for updating book details
  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent default form submission
    try {
      const token = localStorage.getItem('authToken'); // Get token from localStorage
      if (!token) {
        navigate('/login'); // Redirect if no token
        return;
      }

      const response = await axios.put(
        `http://localhost:7000/books/${id}`,
        bookData,
        {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in headers
          },
        }
      );

      if (response.status === 200) {
        setSuccessMessage('Book updated successfully!');
        setTimeout(() => {
          navigate('/'); // Redirect to the homepage after 2 seconds
        }, 2000);
      } else {
        throw new Error('Failed to update book');
      }
    } catch (err) {
      console.error('Error updating book:', err);
      setError(
        err.response?.status === 404
          ? 'Book not found. Cannot update.'
          : 'Failed to update the book. Please try again.'
      );
    }
  };

  return (
    <div className="edit-book-container">
      <h2>Edit Book</h2>
      {error && <p className="error-message">{error}</p>} {/* Display error messages */}
      {successMessage && <p className="success-message">{successMessage}</p>} {/* Display success messages */}
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Title:</label>
          <input
            type="text"
            name="title"
            value={bookData.title}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Author:</label>
          <input
            type="text"
            name="author"
            value={bookData.author}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label>Description:</label>
          <textarea
            name="description"
            value={bookData.description}
            onChange={handleChange}
            required
          ></textarea>
        </div>
        <div className="form-group">
          <label>Cover Image URL:</label>
          <input
            type="url"
            name="coverImage"
            value={bookData.coverImage}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" className="edit-book-button">
          Update Book
        </button>
      </form>
    </div>
  );
};

export default EditBook;
